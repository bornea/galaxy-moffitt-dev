#ifndef ATL_CSYSINFO_H
   #define ATL_CSYSINFO_H

#define ATL_NOMULADD
#define ATL_L1elts 8192
#define ATL_fplat  5
#define ATL_lbnreg 16
#define ATL_mmnreg 16
#define ATL_nkflop 4426278

#endif
