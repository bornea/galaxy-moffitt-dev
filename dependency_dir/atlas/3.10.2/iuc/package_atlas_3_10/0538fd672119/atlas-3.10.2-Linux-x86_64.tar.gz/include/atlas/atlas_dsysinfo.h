#ifndef ATL_DSYSINFO_H
   #define ATL_DSYSINFO_H

#define ATL_NOMULADD
#define ATL_L1elts 16384
#define ATL_fplat  5
#define ATL_lbnreg 16
#define ATL_mmnreg 16
#define ATL_nkflop 4396168

#endif
