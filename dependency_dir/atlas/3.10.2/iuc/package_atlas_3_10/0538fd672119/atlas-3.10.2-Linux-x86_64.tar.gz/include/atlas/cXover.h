#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 240
#define NN_MNK_M 8000
#define NN_MNK_N 72000
#define NN_MNK_MN 64000
#define NN_MNK_K 176720
#define NN_MNK_GE 27000
#define NT_MNK_M 8000
#define NT_MNK_N 8000
#define NT_MNK_MN 64000
#define NT_MNK_K 176720
#define NT_MNK_GE 54872
#define TN_MNK_M 115520
#define TN_MNK_N 115520
#define TN_MNK_MN 64000
#define TN_MNK_K 46080
#define TN_MNK_GE 54872
#define TT_MNK_M 72000
#define TT_MNK_N 8000
#define TT_MNK_MN 64000
#define TT_MNK_K 115520
#define TT_MNK_GE 54872
#define C2R_K 284

#endif
