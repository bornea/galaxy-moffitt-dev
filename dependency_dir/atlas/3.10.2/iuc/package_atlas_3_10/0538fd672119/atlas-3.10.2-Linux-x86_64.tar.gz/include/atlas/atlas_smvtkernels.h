/*
 * This file generated on line 403 of /build/ATLAS/build/..//tune/blas/gemv/mvthgen.c
 */
#ifndef ATLAS_SMVTKERNELS_H
   #define ATLAS_SMVTKERNELS_H

void ATL_smvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900003(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900003_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900003(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900003_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900001(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);
void ATL_smvtk__900001_b0(ATL_CINT, ATL_CINT, const float*, ATL_CINT, const float*, float*);


#endif /* end guard around atlas_smvtkernels.h */
