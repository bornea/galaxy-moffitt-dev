#!/usr/bin/perl

# 27/04/2014

if($#ARGV==0){
	print "This program checks the number of baits in a Saint Output File.\n";
	print "\nusage:\n $0\n-i [csv saint output file]]\n\n";
	die;
}
else{
	$i=0;
	$cutoff=0.01;
	while($i<=$#ARGV){
		if($ARGV[$i] eq '-i'){
			$i++;
			$ifile=$ARGV[$i];
		}
		else{
			die "\Incorrect program usage\n\n";
		}
		$i++;
	}
}

$file='';
open(IFILE,"<$ifile") || die "$ifile can't be opened: $!";
{ local $/=undef;  $file=<IFILE>; }
@lines=split /[\r\n]+/, $file;
foreach $line (@lines) {
	if($line =~ /^Bait/){
	}
	elsif($line =~ /^([^\t]+)/){
		if($1 ne $bait[$baitn]){
			$baitn++;
			$bait[$baitn]=$1;
		}
	}
	else{
	}
}	
close(IFILE);

print $baitn;


